import { useState, useEffect } from "react";

const T = {
  fr: {
    slogan: "Votre prochain voyage commence ici",
    sub: "Donnez votre budget, l'IA trouve la destination parfaite.",
    budget: "Budget (€)", budgetPh: "1500",
    month: "Mois", dur: "Durée",
    months: ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"],
    durs: ["Week-end","1 semaine","10 jours","2 semaines","3 semaines","1 mois"],
    trav: "Voyageurs", trvl: ["1","2","3","4","5+"],
    city: "Départ de", cityPh: "Paris",
    prefs: "Vos envies",
    p: { beach:"Plage", culture:"Culture", adventure:"Aventure", gastro:"Gastro", nightlife:"Soirées", family:"Famille" },
    go: "Trouver mon voyage",
    errB: "Entrez un budget (min 100€)", errD: "Choisissez un mois et une durée",
    errApi: "Erreur lors de la génération. Réessayez.",
    sw: "EN", dest: "Votre destination", prog: "Le programme", tips: "Nos conseils",
    per: { morning: "Matin", afternoon: "Après-midi", evening: "Soirée" },
    cats: { flights:"Vols", hotel:"Hôtel", activities:"Activités", food:"Repas", transport:"Transport" },
    total: "Total", newTrip: "Nouveau voyage",
    ld: ["Analyse du budget...","Recherche de la destination idéale...","Construction du programme jour par jour...","Calcul des meilleurs prix...","Finalisation de votre voyage..."],
  },
  en: {
    slogan: "Your next trip starts here",
    sub: "Give us your budget, AI finds the perfect destination.",
    budget: "Budget (€)", budgetPh: "1500",
    month: "Month", dur: "Duration",
    months: ["January","February","March","April","May","June","July","August","September","October","November","December"],
    durs: ["Weekend","1 week","10 days","2 weeks","3 weeks","1 month"],
    trav: "Travelers", trvl: ["1","2","3","4","5+"],
    city: "From", cityPh: "Paris",
    prefs: "Your interests",
    p: { beach:"Beach", culture:"Culture", adventure:"Adventure", gastro:"Food", nightlife:"Nightlife", family:"Family" },
    go: "Find my trip",
    errB: "Enter a budget (min 100€)", errD: "Select month and duration",
    errApi: "Error generating trip. Please try again.",
    sw: "FR", dest: "Your destination", prog: "The program", tips: "Our tips",
    per: { morning: "Morning", afternoon: "Afternoon", evening: "Evening" },
    cats: { flights:"Flights", hotel:"Hotel", activities:"Activities", food:"Meals", transport:"Transport" },
    total: "Total", newTrip: "New trip",
    ld: ["Analyzing budget...","Finding the ideal destination...","Building your day-by-day program...","Calculating best prices...","Finalizing your trip..."],
  }
};

const PREF_DATA = {
  beach: { gradient: "linear-gradient(135deg, #43CEA2, #185A9D)", icon: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="5" r="3"/><path d="M2 20h20"/><path d="M5 12c1.5-1 3.5-1 5 0s3.5 1 5 0 3.5-1 5 0"/><path d="M5 16c1.5-1 3.5-1 5 0s3.5 1 5 0 3.5-1 5 0"/></svg>
  )},
  culture: { gradient: "linear-gradient(135deg, #8E2DE2, #4A00E0)", icon: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 21h18"/><path d="M5 21V7l7-4 7 4v14"/><path d="M9 21v-4h6v4"/><path d="M9 10h1"/><path d="M14 10h1"/><path d="M9 14h1"/><path d="M14 14h1"/></svg>
  )},
  adventure: { gradient: "linear-gradient(135deg, #11998E, #38EF7D)", icon: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M8 3l4 8 5-5 2 15H2L8 3z"/></svg>
  )},
  gastro: { gradient: "linear-gradient(135deg, #F7971E, #FFD200)", icon: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/><path d="M7 2v20"/><path d="M21 15V2v0a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3zm0 0v7"/></svg>
  )},
  nightlife: { gradient: "linear-gradient(135deg, #0F2027, #2C5364)", icon: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
  )},
  family: { gradient: "linear-gradient(135deg, #FC5C7D, #6A82FB)", icon: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="9" cy="7" r="3"/><circle cx="17" cy="7" r="2"/><path d="M3 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"/><path d="M21 21v-2a3 3 0 0 0-3-3h-1"/></svg>
  )},
};

const BCOLORS = { flights:"#FF8C42", hotel:"#3EC1D3", activities:"#FF6B6B", food:"#A88BEB", transport:"#54C7A0" };
const CAT_ICONS = {
  flights: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17.8 19.2L16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"/></svg>,
  hotel: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 21h18"/><path d="M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16"/><path d="M9 21v-4h6v4"/></svg>,
  activities: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></svg>,
  food: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/><path d="M7 2v20"/><path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3zm0 0v7"/></svg>,
  transport: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>,
};

const DEST_GRADIENTS = [
  "linear-gradient(135deg, #E8A87C 0%, #D4756B 40%, #8B5E83 100%)",
  "linear-gradient(135deg, #43CEA2 0%, #185A9D 100%)",
  "linear-gradient(135deg, #F7971E 0%, #FFD200 100%)",
  "linear-gradient(135deg, #FC5C7D 0%, #6A82FB 100%)",
  "linear-gradient(135deg, #11998E 0%, #38EF7D 100%)",
];

const HERO_GRADIENT = "linear-gradient(135deg, #FF8C42 0%, #E8637C 50%, #8B5CF6 100%)";

export default function App() {
  const [lang, setLang] = useState("fr");
  const [budget, setBudget] = useState("");
  const [month, setMonth] = useState("");
  const [dur, setDur] = useState("");
  const [trav, setTrav] = useState(2);
  const [prefs, setPrefs] = useState([]);
  const [city, setCity] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [ldIdx, setLdIdx] = useState(0);
  const t = T[lang];

  useEffect(() => {
    if (!loading) return;
    const iv = setInterval(() => setLdIdx(i => (i + 1) % t.ld.length), 2500);
    return () => clearInterval(iv);
  }, [loading, t.ld.length]);

  const toggle = p => setPrefs(v => v.includes(p) ? v.filter(x => x !== p) : [...v, p]);

  const generate = async () => {
    setError("");
    if (!budget || +budget < 100) return setError(t.errB);
    if (month === "" || dur === "") return setError(t.errD);

    setLoading(true);
    setLdIdx(0);

    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          budget: +budget,
          travelers: trav,
          month,
          duration: dur,
          city: city || 'Paris',
          preferences: prefs,
          lang,
        }),
      });

      if (!res.ok) throw new Error('API error');
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      // Add a random gradient for the destination
      data.destination.gradient = DEST_GRADIENTS[Math.floor(Math.random() * DEST_GRADIENTS.length)];
      setResult(data);
    } catch (err) {
      console.error(err);
      setError(t.errApi);
    } finally {
      setLoading(false);
    }
  };

  const reset = () => { setResult(null); setBudget(""); setMonth(""); setDur(""); setPrefs([]); setCity(""); };

  const inp = { width: "100%", padding: "12px 14px", background: "#fff", border: "2px solid #EDEDED", borderRadius: "10px", fontSize: "15px", color: "#2D3436", fontFamily: "inherit" };
  const lbl = { display: "block", marginBottom: "6px", fontSize: "12px", fontWeight: 600, color: "#999", textTransform: "uppercase", letterSpacing: "0.5px" };

  return (
    <div style={{ minHeight: "100vh", background: "#FAFAFA", fontFamily: "'Quicksand', system-ui, sans-serif", color: "#2D3436" }}>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        button { cursor: pointer; font-family: 'Quicksand', sans-serif; }
        input, select { font-family: 'Quicksand', sans-serif; }
        input:focus, select:focus { outline: none; border-color: #FF8C42 !important; }
        .cta:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(255,140,66,0.35); }
        @media(max-width:600px) { .g2 { grid-template-columns: 1fr !important; } }
      `}</style>

      {/* LOADING */}
      {loading && (
        <div style={{ position: "fixed", inset: 0, zIndex: 999, background: "rgba(250,250,250,0.97)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "20px" }}>
          <div style={{ width: 40, height: 40, border: "3px solid #EDEDED", borderTop: "3px solid #FF8C42", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
          <div style={{ fontSize: "15px", color: "#FF8C42", fontWeight: 600, transition: "all 0.3s" }}>{t.ld[ldIdx]}</div>
        </div>
      )}

      {/* HEADER */}
      <header style={{ padding: "14px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", background: "#fff", borderBottom: "1px solid #F0F0F0" }}>
        <span style={{ fontSize: "22px", fontWeight: 700, color: "#FF8C42", letterSpacing: "-0.5px" }}>BLECH</span>
        <button onClick={() => setLang(lang === "fr" ? "en" : "fr")} style={{ background: "#F5F5F5", border: "none", borderRadius: "20px", padding: "6px 16px", color: "#666", fontSize: "13px", fontWeight: 700 }}>{t.sw}</button>
      </header>

      <main style={{ maxWidth: "580px", margin: "0 auto", padding: "0 20px 60px" }}>

        {!result ? (
          <div style={{ animation: "fadeUp 0.4s ease" }}>

            {/* HERO */}
            <div style={{ margin: "0 -20px", position: "relative", height: "260px", overflow: "hidden", background: HERO_GRADIENT }}>
              <div style={{ position: "absolute", top: "-30px", right: "-30px", width: "160px", height: "160px", borderRadius: "50%", background: "rgba(255,255,255,0.1)" }} />
              <div style={{ position: "absolute", bottom: "40px", left: "-40px", width: "120px", height: "120px", borderRadius: "50%", background: "rgba(255,255,255,0.08)" }} />
              <div style={{ position: "absolute", top: "60px", right: "60px", width: "60px", height: "60px", borderRadius: "50%", background: "rgba(255,255,255,0.06)" }} />
              <div style={{ position: "absolute", bottom: "32px", left: "24px", right: "24px" }}>
                <h1 style={{ fontSize: "clamp(40px, 10vw, 56px)", fontWeight: 700, color: "#fff", lineHeight: 1, marginBottom: "10px", letterSpacing: "-1px" }}>BLECH</h1>
                <p style={{ fontSize: "16px", color: "rgba(255,255,255,0.9)", fontWeight: 500 }}>{t.slogan}</p>
              </div>
            </div>

            <p style={{ fontSize: "14px", color: "#888", textAlign: "center", margin: "20px 0 28px", fontWeight: 500 }}>{t.sub}</p>

            {/* FORM */}
            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              <div className="g2" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                <div>
                  <label style={lbl}>{t.budget}</label>
                  <input type="number" value={budget} onChange={e => setBudget(e.target.value)} placeholder={t.budgetPh} style={inp} />
                </div>
                <div>
                  <label style={lbl}>{t.trav}</label>
                  <select value={trav} onChange={e => setTrav(+e.target.value)} style={{ ...inp, appearance: "none" }}>
                    {t.trvl.map((l, i) => <option key={i} value={i + 1}>{l}</option>)}
                  </select>
                </div>
              </div>

              <div className="g2" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                <div>
                  <label style={lbl}>{t.month}</label>
                  <select value={month} onChange={e => setMonth(e.target.value)} style={{ ...inp, appearance: "none", color: month !== "" ? "#2D3436" : "#bbb" }}>
                    <option value="">—</option>
                    {t.months.map((m, i) => <option key={i} value={i}>{m}</option>)}
                  </select>
                </div>
                <div>
                  <label style={lbl}>{t.dur}</label>
                  <select value={dur} onChange={e => setDur(e.target.value)} style={{ ...inp, appearance: "none", color: dur !== "" ? "#2D3436" : "#bbb" }}>
                    <option value="">—</option>
                    {t.durs.map((d, i) => <option key={i} value={i}>{d}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label style={lbl}>{t.city}</label>
                <input type="text" value={city} onChange={e => setCity(e.target.value)} placeholder={t.cityPh} style={inp} />
              </div>

              {/* PREFS */}
              <div>
                <label style={{ ...lbl, marginBottom: "10px" }}>{t.prefs}</label>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "8px" }}>
                  {Object.entries(PREF_DATA).map(([k, data]) => {
                    const sel = prefs.includes(k);
                    return (
                      <button key={k} onClick={() => toggle(k)} style={{
                        position: "relative", borderRadius: "12px", overflow: "hidden",
                        border: sel ? "3px solid #FF8C42" : "3px solid transparent",
                        height: "80px", padding: 0, background: data.gradient,
                        transition: "all 0.2s", display: "flex", flexDirection: "column",
                        alignItems: "center", justifyContent: "center", gap: "4px",
                        opacity: sel ? 1 : 0.75,
                      }}>
                        {sel && <div style={{ position: "absolute", inset: 0, background: "rgba(255,140,66,0.2)" }} />}
                        <div style={{ position: "relative", zIndex: 1 }}>{data.icon}</div>
                        <span style={{ position: "relative", zIndex: 1, color: "#fff", fontSize: "11px", fontWeight: 700 }}>{t.p[k]}</span>
                        {sel && <div style={{ position: "absolute", top: "5px", right: "5px", width: "18px", height: "18px", borderRadius: "50%", background: "#FF8C42", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 2 }}>
                          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                        </div>}
                      </button>
                    );
                  })}
                </div>
              </div>

              {error && <div style={{ background: "#FFF0F0", borderRadius: "10px", padding: "10px 16px", color: "#E55", fontSize: "13px", textAlign: "center", fontWeight: 600 }}>{error}</div>}

              <button className="cta" onClick={generate} disabled={loading} style={{
                width: "100%", padding: "16px", background: "#FF8C42", border: "none", borderRadius: "12px",
                color: "#fff", fontSize: "16px", fontWeight: 700, transition: "all 0.2s", opacity: loading ? 0.6 : 1,
              }}>{t.go}</button>
            </div>
          </div>
        ) : (
          /* ===== RESULTS ===== */
          <div style={{ animation: "fadeUp 0.5s ease" }}>

            {/* DESTINATION HERO */}
            <div style={{ margin: "0 -20px", position: "relative", height: "280px", overflow: "hidden", background: result.destination.gradient || DEST_GRADIENTS[0] }}>
              <div style={{ position: "absolute", top: "-40px", right: "-40px", width: "180px", height: "180px", borderRadius: "50%", background: "rgba(255,255,255,0.08)" }} />
              <div style={{ position: "absolute", bottom: "60px", left: "-30px", width: "100px", height: "100px", borderRadius: "50%", background: "rgba(255,255,255,0.06)" }} />
              <div style={{ position: "absolute", bottom: "24px", left: "24px", right: "24px" }}>
                <div style={{ fontSize: "11px", textTransform: "uppercase", letterSpacing: "2px", color: "rgba(255,255,255,0.7)", marginBottom: "6px", fontWeight: 700 }}>{t.dest}</div>
                <h2 style={{ fontSize: "32px", fontWeight: 700, color: "#fff" }}>
                  {result.destination.city}, {result.destination.country}
                </h2>
              </div>
            </div>

            <p style={{ fontSize: "14px", color: "#777", lineHeight: 1.7, margin: "20px 0 24px", textAlign: "center" }}>{result.destination.description}</p>

            {/* BUDGET */}
            <div style={{ background: "#fff", borderRadius: "16px", padding: "22px", boxShadow: "0 1px 8px rgba(0,0,0,0.06)", marginBottom: "24px" }}>
              {(() => {
                const entries = Object.entries(t.cats);
                const total = entries.reduce((s, [k]) => s + (result.budget?.[k] || 0), 0);
                return <>
                  <div style={{ display: "flex", borderRadius: "8px", overflow: "hidden", height: "22px", marginBottom: "18px" }}>
                    {entries.map(([k]) => {
                      const pct = total > 0 ? ((result.budget?.[k] || 0) / total) * 100 : 0;
                      return pct > 0 ? <div key={k} style={{ width: `${pct}%`, background: BCOLORS[k], fontSize: "9px", fontWeight: 700, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}>{pct > 10 ? Math.round(pct) + "%" : ""}</div> : null;
                    })}
                  </div>
                  {entries.map(([k, label]) => (
                    <div key={k} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                        <div style={{ width: 28, height: 28, borderRadius: "8px", background: BCOLORS[k], display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", flexShrink: 0 }}>
                          {CAT_ICONS[k]}
                        </div>
                        <span style={{ fontSize: "13px", color: "#666" }}>{label}</span>
                      </div>
                      <span style={{ fontSize: "14px", fontWeight: 700 }}>{result.budget?.[k] || 0}€</span>
                    </div>
                  ))}
                  <div style={{ borderTop: "1px solid #F0F0F0", paddingTop: "10px", marginTop: "10px", display: "flex", justifyContent: "space-between" }}>
                    <span style={{ fontWeight: 700, color: "#FF8C42", fontSize: "14px" }}>{t.total}</span>
                    <span style={{ fontWeight: 700, color: "#FF8C42", fontSize: "18px" }}>{total}€</span>
                  </div>
                </>;
              })()}
            </div>

            {/* PROGRAMME */}
            <h3 style={{ fontSize: "18px", fontWeight: 700, marginBottom: "14px" }}>{t.prog}</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "24px" }}>
              {result.days?.map((day, i) => (
                <div key={i} style={{ background: "#fff", borderRadius: "14px", overflow: "hidden", boxShadow: "0 1px 8px rgba(0,0,0,0.06)", animation: `fadeUp 0.3s ease ${i * 0.1}s both` }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "12px", padding: "16px 18px", borderBottom: "1px solid #F5F5F5" }}>
                    <div style={{ width: "30px", height: "30px", borderRadius: "50%", background: "#FF8C42", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: "13px", color: "#fff", flexShrink: 0 }}>{i + 1}</div>
                    <div style={{ fontWeight: 700, fontSize: "15px" }}>{day.title}</div>
                  </div>
                  <div style={{ padding: "14px 18px" }}>
                    {["morning", "afternoon", "evening"].map(p => day[p] ? (
                      <div key={p} style={{ marginBottom: "10px", paddingLeft: "12px", borderLeft: `3px solid ${p === "morning" ? "#FFD4A8" : p === "afternoon" ? "#FF8C42" : "#D4756B"}` }}>
                        <div style={{ fontSize: "11px", fontWeight: 700, color: p === "morning" ? "#C49A5C" : p === "afternoon" ? "#FF8C42" : "#D4756B", marginBottom: "3px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{t.per[p]}</div>
                        <div style={{ fontSize: "13px", color: "#555", lineHeight: 1.6 }}>{day[p]}</div>
                      </div>
                    ) : null)}
                  </div>
                </div>
              ))}
            </div>

            {/* TIPS */}
            {result.tips?.length > 0 && (
              <div style={{ background: "#F0FAF5", borderRadius: "14px", padding: "18px", marginBottom: "24px", border: "1px solid #D4EDDF" }}>
                <h3 style={{ fontSize: "14px", color: "#2EAD7A", marginBottom: "12px", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.5px" }}>{t.tips}</h3>
                {result.tips.map((tip, i) => (
                  <div key={i} style={{ display: "flex", gap: "10px", fontSize: "13px", color: "#555", lineHeight: 1.6, marginBottom: "8px" }}>
                    <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#2EAD7A", flexShrink: 0, marginTop: "7px" }} />
                    <span>{tip}</span>
                  </div>
                ))}
              </div>
            )}

            <button className="cta" onClick={reset} style={{
              width: "100%", padding: "16px", background: "#FF8C42", border: "none", borderRadius: "12px",
              color: "#fff", fontSize: "15px", fontWeight: 700, transition: "all 0.2s",
            }}>{t.newTrip}</button>
          </div>
        )}
      </main>
    </div>
  );
}
